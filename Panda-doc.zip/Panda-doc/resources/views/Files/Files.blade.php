@extends('layouts.app')

@section('content')
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>PandaLivery | File</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
    crossorigin="anonymous">
  </head>
  <body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><h5>Panda Files</h5></div>

                      <div class="container">
                        <div class="row">
                          <div class="col-lg-12">

                            <ul>
                              <table id="categoriesTable" class="table">
                                <thead>
                                  <tr>
                                    <th>File Name</th>
                                    <th>size</th>

                                  </tr>
                                </thead>
                              </table>
                            </ul>

                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>
</body>
</html>
@endsection
