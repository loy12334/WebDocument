<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>PandaLivery | File</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
    crossorigin="anonymous">
  </head>
  <body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Upload File</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="container">
                          <div class="row">
                            <div class="col-lg-offset-4 col-lg-4" >

                              <form action="<?php echo e(route('upload.file')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <input type="file" name="file">
                                <br>
                                <br>
                                <input type="submit" value="submit" class="btn btn-info">
                              </form>
                              <!-- <form action="/store" method="post" class="form-horizontal" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <input type="file" name="file">
                                <br>
                                <br>
                                <input type="submit" value="submit" class="btn btn-success">
                              </form> -->

                            </div>
                          </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
</div>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Panda-doc\resources\views/upload/upload.blade.php ENDPATH**/ ?>