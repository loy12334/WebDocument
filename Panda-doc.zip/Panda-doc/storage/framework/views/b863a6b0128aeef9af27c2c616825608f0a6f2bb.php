<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <div class="container">
      <center>
      <h1>File not found</h1>
      <p>Please select file first </p>

      <a class="btn btn-primary" href="upload"> Back</a>
      </center>
  </div>
  </body>
</html>
<?php /**PATH C:\laragon\www\Panda-doc\resources\views/errors/NofileUploaded.blade.php ENDPATH**/ ?>